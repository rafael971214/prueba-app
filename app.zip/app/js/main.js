var counter = 0;

function sleep(ms){
    return new Promise(resolve => setTimeout(resolve, ms));
};

async function main(){
    while(true){
        document.querySelector("#counterCar").textContent = counter
        console.log(counter);
        if(counter == 100){
            break;
        };
        //dalay();
        await sleep(1000);
        counter++;
    };

};

main();
